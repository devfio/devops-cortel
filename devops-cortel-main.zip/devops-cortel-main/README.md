# devops-cortel

Learning DevOps. Cortel.

Какие-то файлы будут проигнорированы в будущем.
